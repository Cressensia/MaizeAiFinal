# maize leaf & disease > 2024-01-23 1:06pm
https://universe.roboflow.com/my-workspace-moljh/maize-leaf-disease

Provided by a Roboflow user
License: CC BY 4.0

