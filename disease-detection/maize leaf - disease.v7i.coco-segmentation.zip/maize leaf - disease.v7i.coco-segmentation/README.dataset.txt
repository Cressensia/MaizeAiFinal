# maize leaf & disease > 2024-01-02 4:06pm
https://universe.roboflow.com/my-workspace-moljh/maize-leaf-disease

Provided by a Roboflow user
License: CC BY 4.0

